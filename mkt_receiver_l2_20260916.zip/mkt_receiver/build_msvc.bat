@echo off
rem mkt_receiver Windows/MSVC 构建
rem 需要: Visual Studio 开发命令行 (cl.exe) ; 直接双击本文件前先开 "x64 Native Tools Command Prompt"
setlocal
if not exist build mkdir build
cl /nologo /O2 /std:c++17 /EHsc /Isrc /Ivendor ^
   vendor\miniz.c src\frame.cpp src\inflate.cpp src\records.cpp src\sink.cpp ^
   src\chan.cpp src\main.cpp ^
   /Fe:build\mkt_recv.exe ws2_32.lib
if errorlevel 1 goto :err
echo == done: build\mkt_recv.exe ==
goto :eof
:err
echo BUILD FAILED
exit /b 1
