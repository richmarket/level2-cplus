# mkt_receiver — Level2 行情 TCP 接收端（C++ 高性能版）

把原 C# 接收端（`ss_level2`：`login.cs` + `SS_data.cs` + `Program.cs`）重写为 C++。
同一套代码可在 **Linux 与 Windows(MSVC)** 编译运行。零外部运行依赖（内置 miniz 处理 gzip）。

> 本包为**纯行情接收端**：只做 6 路 Level2 行情 + 代码表的接收/拆帧/解压/切分/落盘与统计，
> **不含任何下单、交易、券商接口代码**。

## 一、协议（与原版逐条对应）

| 通道 | 端口 | 登录串通道名 | 帧类型标志 | 载荷 |
|---|---|---|---|---|
| index | 32920 | `Index` | `@index_@`(gz) / `@Index_@`(明文) | 指数快照 |
| option | 31920 | `Option` | `@option@` / `@Option@` | 期权快照 |
| market | 33920 | `Market0` | `@market@` / `@Market@` | 十档快照(59字段) |
| queue | 36920 | `Queue0` | `@queue@` / `@Queue@` | 委托队列 |
| tran | 34920 | `Tran0` | `@tran__@` / `@Tran__@` | 逐笔成交 |
| order | 35920 | `Order0` | `@order_@` / `@Order_@` | 逐笔委托 |
| 代码表 | 30920 | `...get_allmarket2...` | — | `begin#...多行\t分隔...#end` |

- **帧格式**：`SS_begin`(8) + 类型(8) + 长度(13 位 ASCII 十进制) + payload(长度字节)
- **压缩规则**：类型第 2 字符**小写** => payload 是 GZip(RFC1952，同 .NET GZipStream)；**大写** => 明文
- **登录串**：`level2_api_33617\nlogin_user\n{user}\n{pass}\nSH_2;SZ_2\n{通道}\n0`（ASCII）
- **心跳**：服务器在帧间发送 `Heart_beart`(11 字节)；看门狗 30s 无数据断线重连（可配）
- **记录**：payload 内按 `#` 分条、条内按 `|` 分字段（同 `Split('#')/Split('|')` 且跳过空段）
- market 字段位（0 起）：`[0]标准代码 [1]代码 [2]日期 [3]时间 [4]状态 [5]前收 [6]开 [7]高 [8]低 [9]最新`
  `[10-19]卖价1-10 [20-29]卖量1-10 [30-39]买价1-10 [40-49]买量1-10 [50]笔数 [51]总量`
  `[52]总金额 [53]委买总量 [54]委卖总量 [55]均委买 [56]均委卖 [57]涨停 [58]跌停`

## 二、为什么比 C# 版快（架构）

原版瓶颈逐条对照：

| C# 原版 | 本版 |
|---|---|
| 每通道 `BeginReceive` 用 **64 字节**缓冲，每次回调 new byte[] + 拷入队列 | 1MB 大块阻塞 recv，`SO_RCVBUF` 8MB |
| `List<byte>` 从头 `RemoveRange`，O(n²) 搬运 | 指针游标 + 阈值紧凑，平摊 O(n) |
| 每 8/11/13 字节都 new 数组 + `UTF8.GetString` + `int.Parse` | `memmem` 直接定位、手写 ASCII 解析 |
| GZipStream 每次 new MemoryStream | miniz 解压到复用缓冲（跨帧零分配） |
| `Split('#')/Split('|')` 每字段建 string/数组 → GC 风暴 | 零拷贝视图（指针+长度），**全程无堆分配** |
| 每通道 1 收包线程 + 1 解析线程 + ConcurrentQueue 拷贝 | 每通道单线程：收包→拆帧→解压→切分→sink，同步直通 |
| 落盘用每代码一个 StreamWriter(未缓冲) | FILE* + 每文件 1MB/8MB 分级缓冲 |

> 消息路径上不 new 任何对象：帧切分（`feed_stream`）、gzip 解压输出（`std::vector` 复用）、记录切分（`RecordView` 栈/复用数组）全是原地指针运算。数值解析手写、不做 locale/异常。

实测（本机，全链路：分片喂流→拆帧→gzip 解压→切记录）：
**≈262 万条记录/秒**（5000 只全市场快照帧 1.2MB，27.8x 压缩），单帧(1.2MB/5000 条)端到端 ~1.9ms；
该数字是每轮重建缓冲的保守口径，真实常驻运行（缓冲复用）会更高。

## 三、构建

Linux：
```bash
bash build.sh          # 产物 build/mkt_recv
```
> 有 zig 则用 zig 静态编译；否则用系统 g++/clang++。gzip 用内置 miniz（vendor/miniz.c），无需装 zlib。

Windows(MSVC)：装好 VS 后开 "x64 Native Tools Command Prompt"：
```
build_msvc.bat         # 产物 build\mkt_recv.exe (链接 ws2_32)
```

## 四、运行

```bash
./build/mkt_recv \
  --ip <行情IP> --user <账号> --pass <密码> \
  --chans market,tran,order,index,queue,option \
  --stats-sec 5 --watchdog 30
```

参数：
- `--ip / --user / --pass`：行情服务器地址与登录账号（**本包不含任何默认值，必须由调用方传入**）
- `--chans`：要连的通道，逗号分隔（`market,tran,order,index,queue,option`）
- `--write-files --out out`：镜像原版落盘 `out/{日期}/{通道}/{代码}_{日期}.csv`（记录内 `|`→`,` + 接收时间）
- `--verbose`：连接/断开/解压失败日志
- `--list`：拉一次全市场代码表数量后退出
- `--selftest`：离线自测（不联网，验证拆帧/解压/解析）
- `--watchdog 30`：心跳看门狗秒数；`--reconnect-ms 5000`：重连退避
- `--stats-sec 5`：统计打印周期
- 环境变量 `L2_IP / L2_USER / L2_PASS` 可覆盖（避免密码上命令行）
- Ctrl-C 优雅退出

> 账号/密码/地址均不内置：源码里 `Config` 三项默认为空串，只接受命令行或环境变量传入。

## 五、统计输出字段

```
HHMMSSmmm <通道> <rec/s> tot=<累计条数> blk=<内核积压KB> age=<数据龄期ms> mx=<最大龄期> gzMB=<累计解压MB> fails=<解压失败> recon=<重连次数>
HHMMSSmmm CPU <x.x%>
```
- `blk`：socket 内核接收队列积压（KB）
- `age`：最新记录时间戳与当前时间的差（北京时区，与时区无关）
- `fails` 恒为 0 表示解压链路健康；`recon` 在断线重连时增长

## 六、文件

```
src/common.hpp    配置/通道表/socket 封装/工具
src/frame.*       TCP 流 -> 帧 (SS_begin 扫描/长度/心跳跳过)
src/inflate.*     gzip 解压/压缩 (miniz)
src/records.*     记录按 # 切分、字段按 | 切分(零拷贝)
src/sink.*        数据出口: 统计 / 文件落盘
src/chan.*        每路通道线程(登录/看门狗/重连/主循环)
src/main.cpp      主程序/参数/统计打印/离线自测
vendor/miniz.*    gzip 实现(公共域/ MIT)
```
