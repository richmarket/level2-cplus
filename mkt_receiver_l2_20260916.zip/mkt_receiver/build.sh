#!/usr/bin/env bash
# 构建 mkt_receiver —— 纯 Level2 行情 TCP 接收端（只此一个可执行文件）
# 优先 zig -> g++/clang++；Linux/macOS 用本脚本，Windows 用 build_msvc.bat
set -e
cd "$(dirname "$0")"
mkdir -p build

ZIG="${ZIG:-$HOME/.local/zig/zig}"
if [ ! -x "$ZIG" ]; then ZIG="$(command -v zig || true)"; fi

SRCS="src/frame.cpp src/inflate.cpp src/records.cpp src/sink.cpp src/chan.cpp"

if [ -n "$ZIG" ] && [ -x "$ZIG" ]; then
  echo "== build with zig =="
  [ -f build/miniz.o ] || "$ZIG" cc -O2 -c vendor/miniz.c -o build/miniz.o
  "$ZIG" c++ -O2 -std=c++17 -Isrc -Ivendor $SRCS src/main.cpp build/miniz.o -o build/mkt_recv -pthread
else
  echo "== build with system compiler =="
  CC="${CC:-gcc}"; CXX="${CXX:-g++}"
  [ -f build/miniz.o ] || $CC -O2 -c vendor/miniz.c -o build/miniz.o
  $CXX -O2 -std=c++17 -Isrc -Ivendor $SRCS src/main.cpp build/miniz.o -o build/mkt_recv -pthread
fi
echo "== done: build/mkt_recv =="
