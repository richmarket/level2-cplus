#include "sink.hpp"
#include <unordered_map>
#include <cstdio>
#include <cstring>
#include <sys/stat.h>

namespace mkt {

// 统一行缓冲容量: 记录最长 ~4KB (queue 100 字段), 常规 <1KB
static constexpr size_t LINE_CAP = 64 * 1024;

FileSink::~FileSink() {
    for (auto& cf : files_) {
        for (auto& kv : cf.by_code) {
            if (kv.second.f) { fflush(kv.second.f); fclose(kv.second.f); }
        }
        cf.by_code.clear();
    }
}

static void ensure_dir(const std::string& path) {
#ifdef _WIN32
    _mkdir(path.c_str());
#else
    mkdir(path.c_str(), 0755);
#endif
}

// 取记录 code(第2字段; 失败取标准代码[0]前6位) 与日期(第3字段)
static void rec_code_date(const RecordView& r, std::string& code, std::string& date) {
    code.clear(); date.clear();
    FieldView f[8];
    size_t nf = split_fields(r, f, 8);
    if (nf > 1) code.assign(f[1].p, f[1].n);
    if (code.empty() && nf > 0) code.assign(f[0].p, std::min<size_t>(f[0].n, 6));
    if (nf > 2) date.assign(f[2].p, f[2].n);
    if (date.empty()) date = "00000000";
}

void FileSink::on_records(Chan ch, const RecordView* recs, size_t count) {
    const char* chname = CH_SPEC[ch].name;
    auto& m = files_[ch].by_code;
    static thread_local std::string line;   // 每线程复用行缓冲
    static thread_local char rxbuf[16];
    line.reserve(LINE_CAP);

    for (size_t i = 0; i < count; ++i) {
        const RecordView& r = recs[i];
        std::string code, date;
        rec_code_date(r, code, date);
        if (code.empty()) continue;

        auto it = m.find(code);
        if (it == m.end()) {
            // out/{date}/{channel}/{code}_{date}.csv
            std::string dir = dir_ + "/" + date + "/" + chname;
            ensure_dir(dir_); ensure_dir(dir_ + "/" + date); ensure_dir(dir);
            OutFile of;
            of.path = dir + "/" + code + "_" + date + ".csv";
            of.f = fopen(of.path.c_str(), "ab");
            if (of.f) {
                // 大缓冲: 每文件 1MB, 降低高频小写 syscall
                setvbuf(of.f, nullptr, _IOFBF, 1u << 20);
            } else {
                continue;
            }
            it = m.emplace(code, std::move(of)).first;
        }
        OutFile& of = it->second;
        if (!of.f) continue;

        // 组行: 记录内 '|' -> ',' , 追加 "," + 接收时间 + "\n"
        line.clear();
        const char* p = r.begin;
        size_t n = r.len;
        for (size_t k = 0; k < n; ++k) {
            char c = p[k];
            line.push_back(c == '|' ? ',' : c);
        }
        snprintf(rxbuf, sizeof rxbuf, ",%s\n", local_hhmmssfff().c_str());
        line.append(rxbuf);
        fwrite(line.data(), 1, line.size(), of.f);
        of.since_flush += line.size();
        if (of.since_flush >= (8u << 20)) {   // 单文件累计 8MB 缓冲满自动落盘
            fflush(of.f);
            of.since_flush = 0;
        }
    }
}

} // namespace mkt
