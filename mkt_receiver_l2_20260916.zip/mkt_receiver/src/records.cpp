#include "records.hpp"
#include "common.hpp"

namespace mkt {

// split_records: 按 '#' 切。记录可能以'#'起始/结尾 -> 跳过空段。
size_t split_records(const char* p, size_t n, RecordView* recs, size_t max) {
    size_t count = 0;
    size_t seg_start = 0;
    for (size_t i = 0; i < n; ++i) {
        if (p[i] == '#') {
            size_t len = i - seg_start;
            if (len > 0) {                       // RemoveEmptyEntries
                if (count == max) return count;  // 缓冲满(实际极少发生: 帧内记录<8192)
                recs[count].begin = p + seg_start;
                recs[count].len   = len;
                ++count;
            }
            seg_start = i + 1;
        }
    }
    size_t len = n - seg_start;
    if (len > 0 && count < max) {
        recs[count].begin = p + seg_start;
        recs[count].len   = len;
        ++count;
    }
    return count;
}

size_t split_fields(const RecordView& r, FieldView* flds, size_t max) {
    const char* p = r.begin;
    size_t n = r.len;
    size_t count = 0;
    size_t seg_start = 0;
    for (size_t i = 0; i < n; ++i) {
        if (p[i] == '|') {
            size_t len = i - seg_start;
            if (len > 0 && count < max) {
                flds[count].p = p + seg_start;
                flds[count].n = len;
                ++count;
            }
            seg_start = i + 1;
        }
    }
    size_t len = n - seg_start;
    if (len > 0 && count < max) {
        flds[count].p = p + seg_start;
        flds[count].n = len;
        ++count;
    }
    return count;
}

} // namespace mkt
