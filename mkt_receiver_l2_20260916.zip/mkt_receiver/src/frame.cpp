#include "frame.hpp"
#include <cstring>
#include <algorithm>

namespace mkt {

static const char SS_BEGIN[8] = {'S','S','_','b','e','g','i','n'};

static inline const uint8_t* find_bytes(const uint8_t* p, size_t n,
                                        const char* needle, size_t m) {
    if (m > n) return nullptr;
    const uint8_t* end = p + n - m;
    for (const uint8_t* q = p; q <= end; ++q) {
        if (q[0] == (uint8_t)needle[0] && memcmp(q, needle, m) == 0) return q;
    }
    return nullptr;
}

// 13 位 ASCII 十进制长度(前导0填充), 异常返回 -1
static int64_t parse_len(const uint8_t* p, size_t n) {
    int64_t v = 0;
    bool any = false;
    for (size_t i = 0; i < n; ++i) {
        if (p[i] < '0' || p[i] > '9') continue;
        any = true;
        v = v * 10 + (p[i] - '0');
        if (v > (int64_t)MAX_PAYLOAD) return -1;
    }
    return any ? v : -1;
}

// buf 尾部是否有 "SS_begin" 的前缀(可能跨 TCP 包), 返回应保留的字节数
static size_t partial_head_tail(const uint8_t* p, size_t n) {
    size_t keep = std::min<size_t>(n, 7);
    for (size_t k = keep; k >= 1; --k) {
        if (memcmp(p + n - k, SS_BEGIN, k) == 0) return k;
    }
    return 0;
}

size_t feed_stream(std::vector<uint8_t>& buf, size_t& pos,
                   const uint8_t* data, size_t n,
                   const std::function<void(const Frame&)>& on_frame) {
    // 0) 追加前先紧凑(丢弃已消费前缀), 防止缓冲无限膨胀
    if (pos > 0 && pos == buf.size()) { buf.clear(); pos = 0; }
    else if (pos > 0 && (pos >= buf.size() / 2)) {
        std::memmove(buf.data(), buf.data() + pos, buf.size() - pos);
        buf.resize(buf.size() - pos);
        pos = 0;
    }
    buf.insert(buf.end(), data, data + n);

    size_t frames = 0;
    size_t cursor = pos;
    const uint8_t* base = buf.data();
    size_t size = buf.size();

    while (cursor + FRAME_HEAD <= size) {
        // 1) 找下一个 SS_begin (跳过其间的心跳包/垃圾)
        const uint8_t* start = find_bytes(base + cursor, size - cursor, SS_BEGIN, 8);
        if (!start) {
            // 无帧头: 丢弃垃圾, 但保留可能是帧头前缀的末尾若干字节
            size_t keep = partial_head_tail(base + cursor, size - cursor);
            cursor = size - keep;
            break;
        }
        size_t off = (size_t)(start - base);
        cursor = off;
        if (off + FRAME_HEAD > size) break;              // 帧头未到齐

        // 2) 类型 8 字节: 小写首字母(第2字符) => gzip
        const uint8_t* ft = base + off + 8;
        char type[9]; memcpy(type, ft, 8); type[8] = 0;
        bool gzip = (ft[1] >= 'a' && ft[1] <= 'z');

        // 3) 长度 13 位 ASCII
        int64_t plen = parse_len(base + off + 16, 13);
        if (plen < 0) {                       // 坏帧: 前移1字节再找
            cursor = off + 1;
            continue;
        }
        size_t frame_end = off + FRAME_HEAD + (size_t)plen;
        if (frame_end > size) break;          // payload 未到齐, 等更多数据

        // 4) 成帧回调
        Frame f;
        f.payload = base + off + FRAME_HEAD;
        f.len = (size_t)plen;
        f.gzip = gzip;
        memcpy(f.type, type, 9);
        on_frame(f);
        ++frames;
        cursor = frame_end;
    }

    // 5) 更新消费位置 & 紧凑
    if (cursor > 0) {
        if (cursor >= buf.size()) { buf.clear(); pos = 0; }
        else {
            size_t remain = buf.size() - cursor;
            if (cursor >= remain / 2 || remain < FRAME_HEAD) { // 已消费占比大 -> 前移
                std::memmove(buf.data(), buf.data() + cursor, remain);
                buf.resize(remain);
                pos = 0;
            } else {
                pos = cursor;
            }
        }
    }
    return frames;
}

} // namespace mkt
