// 帧扫描器: TCP 字节流 -> 完整帧
// 帧格式 (与 login.cs 注释一致): SS_begin(8) + type(8) + len(13位ASCII数字) + payload(len)
//   type 第2字符小写(如 @market@) => payload 为 GZip 压缩; 大写(如 @Market@) => 明文
#pragma once

#include <cstdint>
#include <cstddef>
#include <vector>
#include <functional>

namespace mkt {

struct Frame {
    const uint8_t* payload;   // 指向流缓冲内 payload 起点 (仅在回调内有效)
    size_t         len;       // payload 字节数
    bool           gzip;      // true=需解压, false=明文
    char           type[9];   // 8字节类型串 + NUL
};

constexpr size_t FRAME_HEAD = 8 + 8 + 13;   // SS_begin + type + len
constexpr size_t MAX_PAYLOAD = 512u * 1024 * 1024; // 单帧上限(防伪包)

// 把新收到的字节追加进流缓冲, 并逐帧回调。返回解析出的帧数。
// buf/pos: 流缓冲及已消费偏移(帧头/心跳/垃圾会从 pos 前移走)
size_t feed_stream(std::vector<uint8_t>& buf, size_t& pos,
                   const uint8_t* data, size_t n,
                   const std::function<void(const Frame&)>& on_frame);

} // namespace mkt
