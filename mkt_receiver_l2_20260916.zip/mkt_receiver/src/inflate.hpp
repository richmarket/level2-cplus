// GZip 解压/压缩封装 (基于 miniz, 单文件, 无系统依赖; Windows/Linux 通用)
// .NET GZipStream = RFC1952 gzip 格式, 需自解析 gzip 头 + raw-deflate
#pragma once

#include <cstdint>
#include <cstddef>
#include <vector>

namespace mkt {

// 解压整块 gzip 数据到 out(复用缓冲)。返回 true=成功。
// 输入可能是多段 gzip 首尾相接? 原版每帧一个 GZipStream => 单段。若 flg 带扩展直接跳过。
bool gunzip(const uint8_t* in, size_t in_len, std::vector<uint8_t>& out);

// 压缩 (仅供自测/工具用): 输入 -> gzip 格式
bool gzip_compress(const uint8_t* in, size_t in_len, std::vector<uint8_t>& out);

} // namespace mkt
