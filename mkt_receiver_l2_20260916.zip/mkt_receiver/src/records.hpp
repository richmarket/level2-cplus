// 记录切分与字段视图 (零拷贝, 只在原始缓冲上切指针)
// 原版 C#: 解压后文本按 '#' 分条(RemoveEmptyEntries), 每条内按 '|' 分字段
#pragma once

#include <cstdint>
#include <cstddef>
#include "common.hpp"

namespace mkt {

struct FieldView {
    const char* p;
    size_t      n;
};

struct RecordView {
    const char* begin;   // 记录起点(含字段分隔符原文)
    size_t      len;     // 记录长度(不含'#'定界)
};

// 把 payload 按 '#' 切成若干记录(跳过空段), 写入 recs, 返回条数(<=max)
// 与 C# Split('#', RemoveEmptyEntries) 语义一致
size_t split_records(const char* p, size_t n, RecordView* recs, size_t max);

// 记录内按 '|' 切字段(跳过空段), 返回字段数(<=max)
size_t split_fields(const RecordView& r, FieldView* flds, size_t max);

// 字段快速访问辅助: 第 idx 个字段的整数/文本 (超出返回0/空)
inline int64_t field_i64(const FieldView* flds, size_t nf, size_t idx) {
    return idx < nf ? parse_i64(flds[idx].p, flds[idx].n) : 0;
}

} // namespace mkt
