// 单路行情通道: 连接 -> 登录 -> 收流 -> 拆帧 -> 解压 -> 拆记录 -> sink
// 心跳看门狗/断线重连语义与 C# login.cs 一致 (30s 无数据重连, 5s 退避)
#pragma once

#include "common.hpp"
#include "frame.hpp"
#include "sink.hpp"
#include <thread>
#include <vector>

namespace mkt {

class Channel {
public:
    Channel(Chan ch, Sink& sink);
    ~Channel();
    void start();     // 起线程
    void stop();      // 请求停止(关 socket 以打断 recv)

    Chan   kind() const { return ch_; }
    ChanStats* stats() { return &stats_; }
    // 内核接收缓冲当前积压字节数(FIONREAD); 无连接/-1
    int64_t backlog_bytes() const;

private:
    void run();
    void process_frame(const Frame& f, std::vector<uint8_t>& txt,
                       std::vector<RecordView>& recs);
    void sleep_steps(int ms);
    bool connect_and_login(sock_t& s);

    Chan ch_;
    Sink& sink_;
    ChanStats stats_;
    std::thread th_;
    std::atomic<bool> stop_{false};
    std::atomic<sock_t> sock_{INVALID_SOCK};
};

// 可选: 拉全市场代码表 (30920, 对应 Program.cs getallmarket), 返回条数; <0=失败
int64_t fetch_code_list(const Config& cfg, std::string* out_raw = nullptr);

} // namespace mkt
