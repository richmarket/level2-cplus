#include "inflate.hpp"
#include "miniz.h"
#include <cstring>
#include <algorithm>

namespace mkt {

// ---- gzip 头解析: 跳过 magic(2)+cm(1)+flg(1)+mtime(4)+xfl(1)+os(1)=10 + 可选扩展
static bool skip_gzip_header(const uint8_t* p, size_t n, size_t& body_off) {
    if (n < 18) return false;                    // 10 头 + 最小 deflate + 8 尾
    if (p[0] != 0x1f || p[1] != 0x8b || p[2] != 8) return false;
    uint8_t flg = p[3];
    size_t o = 10;
    if (flg & 0x04) {                            // FEXTRA
        if (o + 2 > n) return false;
        size_t xlen = (size_t)p[o] | ((size_t)p[o + 1] << 8);
        o += 2 + xlen;
    }
    if (flg & 0x08) {                            // FNAME
        while (o < n && p[o] != 0) ++o;
        if (o >= n) return false; ++o;
    }
    if (flg & 0x10) {                            // FCOMMENT
        while (o < n && p[o] != 0) ++o;
        if (o >= n) return false; ++o;
    }
    if (flg & 0x02) o += 2;                      // FHCRC
    if (o + 8 > n) return false;                 // 至少剩 deflate+8 尾
    body_off = o;
    return true;
}

// miniz 3.0.2 tinfl_decompress 输出语义:
//   *pOut_buf_size = 本次可写容量; 返回后 = 本次实际写入字节数
//   需 TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF (非 2 的幂输出缓冲也允许)
bool gunzip(const uint8_t* in, size_t in_len, std::vector<uint8_t>& out) {
    size_t body_off = 0;
    if (!skip_gzip_header(in, in_len, body_off)) return false;
    const uint8_t* body = in + body_off;
    size_t body_len = in_len - body_off - 8;     // 去掉 CRC32+ISIZE 尾部

    tinfl_decompressor dec;
    tinfl_init(&dec);

    out.clear();
    size_t cap = std::max<size_t>(128, body_len * 3 + 1024);  // 文本膨胀率通常<3
    out.resize(cap);

    size_t src_ofs = 0;      // 已消费输入
    size_t written = 0;      // 已产出输出
    for (;;) {
        size_t avail_in  = body_len - src_ofs;
        size_t avail_out = out.size() - written;
        tinfl_status st = tinfl_decompress(&dec, body + src_ofs, &avail_in,
                                           out.data(), out.data() + written,
                                           &avail_out,
                                           TINFL_FLAG_USING_NON_WRAPPING_OUTPUT_BUF);
        src_ofs += avail_in;
        written += avail_out;
        if (st == TINFL_STATUS_DONE) {
            out.resize(written);
            return true;
        }
        if (st == TINFL_STATUS_HAS_MORE_OUTPUT) {
            if (out.size() >= (1u << 30)) return false;   // 防膨胀炸弹
            out.resize(out.size() * 2);
            continue;
        }
        // FAILED / NEEDS_MORE_INPUT / ADLER32_MISMATCH / BAD_PARAM
        return false;
    }
}

bool gzip_compress(const uint8_t* in, size_t in_len, std::vector<uint8_t>& out) {
    // 1) raw deflate (miniz 3.0.2 tdefl 为经典签名)
    size_t raw_cap = in_len + in_len / 2 + 4096;
    std::vector<uint8_t> raw(raw_cap);
    tdefl_compressor comp;
    tdefl_init(&comp, nullptr, nullptr, TDEFL_DEFAULT_MAX_PROBES);
    size_t in_left = in_len;
    size_t raw_used = 0;
    tdefl_status st;
    do {
        size_t in_chunk = in_left;
        size_t out_chunk = raw.size() - raw_used;
        st = tdefl_compress(&comp, in + (in_len - in_left), &in_chunk,
                            raw.data() + raw_used, &out_chunk,
                            in_left == in_chunk ? TDEFL_FINISH : TDEFL_NO_FLUSH);
        in_left -= in_chunk;
        raw_used += out_chunk;
        if (raw_used == raw.size()) raw.resize(raw.size() * 2);   // 防满
    } while (st != TDEFL_STATUS_DONE && st > 0);
    if (st != TDEFL_STATUS_DONE) return false;
    raw.resize(raw_used);

    // 2) 组装 gzip: 头 + deflate + crc32 + isize
    out.clear();
    out.reserve(10 + raw.size() + 8);
    static const uint8_t hdr[10] = {0x1f, 0x8b, 8, 0, 0, 0, 0, 0, 0, 0xff}; // mtime=0, OS=0xff
    out.insert(out.end(), hdr, hdr + 10);
    out.insert(out.end(), raw.begin(), raw.end());
    mz_ulong crc = (mz_ulong)mz_crc32(MZ_CRC32_INIT, in, in_len);
    uint8_t tail[8];
    tail[0] = (uint8_t)(crc & 0xff);         tail[1] = (uint8_t)((crc >> 8) & 0xff);
    tail[2] = (uint8_t)((crc >> 16) & 0xff); tail[3] = (uint8_t)((crc >> 24) & 0xff);
    uint32_t isz = (uint32_t)in_len;
    tail[4] = (uint8_t)(isz & 0xff);         tail[5] = (uint8_t)((isz >> 8) & 0xff);
    tail[6] = (uint8_t)((isz >> 16) & 0xff); tail[7] = (uint8_t)((isz >> 24) & 0xff);
    out.insert(out.end(), tail, tail + 8);
    return true;
}

} // namespace mkt
