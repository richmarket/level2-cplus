#include "chan.hpp"
#include "frame.hpp"
#include "inflate.hpp"
#include "records.hpp"
#include <cstring>
#include <chrono>
#include <thread>
#ifdef _WIN32
  #include <winsock2.h>
#else
  #include <sys/ioctl.h>
#endif

namespace mkt {

const ChanSpec CH_SPEC[CH_NUM] = {
    {"index",  "Index",  "@index_@",  32920},
    {"option", "Option", "@option@",  31920},
    {"market", "Market0","@market@",  33920},
    {"queue",  "Queue0", "@queue@",   36920},
    {"tran",   "Tran0",  "@tran__@",  34920},
    {"order",  "Order0", "@order_@",  35920},
};

Config g_cfg;
std::atomic<bool> g_stop{false};

// ---------------------------------------------------------------- socket helpers
static sock_t tcp_connect(const std::string& ip, int port, int rcvbuf) {
    sock_t s = socket(AF_INET, SOCK_STREAM, 0);
    if (s == INVALID_SOCK) return INVALID_SOCK;
    sockaddr_in addr{};
    addr.sin_family = AF_INET;
    addr.sin_port = htons((uint16_t)port);
    if (inet_pton(AF_INET, ip.c_str(), &addr.sin_addr) != 1) { sock_close(s); return INVALID_SOCK; }
    if (rcvbuf > 0) {
        int v = rcvbuf;
        setsockopt(s, SOL_SOCKET, SO_RCVBUF, (const char*)&v, sizeof v);
    }
    if (connect(s, (sockaddr*)&addr, sizeof addr) != 0) { sock_close(s); return INVALID_SOCK; }
    return s;
}

static bool send_all(sock_t s, const void* data, size_t n) {
    const char* p = (const char*)data;
    while (n > 0) {
#ifdef _WIN32
        int w = send(s, p, (int)std::min<size_t>(n, 1u << 20), 0);
#else
        ssize_t w = send(s, p, std::min<size_t>(n, 1u << 20), MSG_NOSIGNAL);
#endif
        if (w <= 0) return false;
        p += w; n -= (size_t)w;
    }
    return true;
}

Channel::Channel(Chan ch, Sink& sink) : ch_(ch), sink_(sink) {}

Channel::~Channel() { stop(); if (th_.joinable()) th_.join(); }

void Channel::stop() {
    stop_.store(true);
    sock_t s = sock_.exchange(INVALID_SOCK);
    if (s != INVALID_SOCK) sock_shutdown(s);   // 打断阻塞 recv
}

bool Channel::connect_and_login(sock_t& s) {
    s = tcp_connect(g_cfg.ip, CH_SPEC[ch_].port, g_cfg.rcvbuf);
    if (s == INVALID_SOCK) return false;
    std::string msg = std::string("level2_api_33617\nlogin_user\n") + g_cfg.user + "\n" +
                      g_cfg.pass + "\nSH_2;SZ_2\n" + CH_SPEC[ch_].login + "\n0";
    bool ok = send_all(s, msg.data(), msg.size());
    if (!ok) { sock_close(s); s = INVALID_SOCK; return false; }
#ifdef _WIN32
    DWORD tv = 3000; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, (const char*)&tv, sizeof tv);
#else
    timeval tv{3, 0}; setsockopt(s, SOL_SOCKET, SO_RCVTIMEO, &tv, sizeof tv);
#endif
    sock_.store(s);
    return true;
}

void Channel::start() { th_ = std::thread([this] { run(); }); }

// 内核接收缓冲积压字节数(FIONREAD); 积压大=处理跟不上, 延迟会涨
int64_t Channel::backlog_bytes() const {
    sock_t s = sock_.load(std::memory_order_relaxed);
    if (s == INVALID_SOCK) return -1;
#ifdef _WIN32
    u_long n = 0;
    if (ioctlsocket(s, FIONREAD, &n) == 0) return (int64_t)n;
#else
    int n = 0;
    if (ioctl(s, FIONREAD, &n) == 0) return (int64_t)n;
#endif
    return -1;
}

// 取一帧"数据龄期": 帧内首条记录的行情时间 vs 本地解析时刻
// 用记录自带 日期[2]+时间[3] 换算 UTC epoch, 与容器/机器时区无关
static void update_age(ChanStats& st, const char* p, size_t plen) {
    RecordView rv[4];
    size_t nr = split_records(p, plen, rv, 4);
    if (nr == 0) return;
    FieldView f[8];
    size_t nf = split_fields(rv[0], f, 8);
    if (nf <= 3) return;
    int64_t rec_ms = rec_epoch_ms(parse_i64(f[2].p, f[2].n),
                                  parse_i64(f[3].p, f[3].n));
    if (rec_ms < 0) return;
    int64_t age = now_epoch_ms() - rec_ms;
    if (age < 0 || age > 6 * 3600000) return;  // 异常/回放数据丢弃(限6h内)
    st.age_latest.store(age, std::memory_order_relaxed);
    int64_t prev = st.age_max.load(std::memory_order_relaxed);
    while (age > prev && !st.age_max.compare_exchange_weak(prev, age,
                    std::memory_order_relaxed, std::memory_order_relaxed)) {}
}

// 处理一帧: 解压(如需) -> 按'#'切记录 -> 分批复用缓冲交给 sink
void Channel::process_frame(const Frame& f, std::vector<uint8_t>& txt,
                            std::vector<RecordView>& recs) {
    stats_.frames.fetch_add(1, std::memory_order_relaxed);
    const char* p;
    size_t plen;
    if (f.gzip) {
        stats_.bytes_gz.fetch_add(f.len, std::memory_order_relaxed);
        if (!gunzip(f.payload, f.len, txt)) {
            stats_.inflate_fail.fetch_add(1, std::memory_order_relaxed);
            if (g_cfg.verbose)
                log_msg(CH_SPEC[ch_].name, std::string("gunzip fail type=") + f.type);
            return;
        }
        p = (const char*)txt.data(); plen = txt.size();
    } else {
        p = (const char*)f.payload; plen = f.len;
    }
    stats_.bytes_txt.fetch_add(plen, std::memory_order_relaxed);
    update_age(stats_, p, plen);

    const size_t max = recs.size();
    size_t off = 0;
    while (off < plen) {
        size_t n = split_records(p + off, plen - off, recs.data(), max);
        if (n == 0) break;
        stats_.recs.fetch_add(n, std::memory_order_relaxed);
        sink_.on_records(ch_, recs.data(), n);
        if (n < max) break;                       // 已到帧尾
        off = (size_t)(recs[n - 1].begin - p) + recs[n - 1].len;  // 续传起点
        while (off < plen && p[off] == '#') ++off;
    }
}

void Channel::run() {
    std::vector<uint8_t> stream;                  // 跨包流缓冲
    std::vector<uint8_t> txt;                     // 解压输出(复用)
    std::vector<RecordView> recs(1u << 17);       // 记录批缓冲 131072 条
    size_t stream_pos = 0;
    std::vector<char> chunk(1u << 20);            // 每次 recv 1MB

    log_msg(CH_SPEC[ch_].name, "thread started");
    int64_t last_rx = 0;

    while (!stop_.load()) {
        sock_t s;
        if (!connect_and_login(s)) {
            if (g_cfg.verbose)
                log_msg(CH_SPEC[ch_].name, "connect/login failed, retry");
            sleep_steps(g_cfg.reconnect_delay_ms);
            continue;
        }
        stats_.reconnect.fetch_add(1, std::memory_order_relaxed);
        last_rx = now_ms();   // 与 C# 一致: 登录即起看门狗计时
        if (g_cfg.verbose)
            log_msg(CH_SPEC[ch_].name, "connected");

        while (!stop_.load()) {
            int64_t now = now_ms();
            if (now - last_rx > (int64_t)g_cfg.watchdog_sec * 1000) {
                log_msg(CH_SPEC[ch_].name, "watchdog timeout, reconnect");
                break;
            }
            int r;
#ifdef _WIN32
            r = recv(s, chunk.data(), (int)chunk.size(), 0);
#else
            r = (int)recv(s, chunk.data(), chunk.size(), 0);
#endif
            if (r > 0) {
                last_rx = now_ms();
                stats_.bytes_in.fetch_add((uint64_t)r, std::memory_order_relaxed);
                feed_stream(stream, stream_pos, (const uint8_t*)chunk.data(), (size_t)r,
                            [&](const Frame& f) { process_frame(f, txt, recs); });
            } else if (r == 0) {
                if (!stop_.load())
                    log_msg(CH_SPEC[ch_].name, "peer closed");
                break;
            } else {
                // 超时/中断: 醒来检查看门狗与停止
#ifdef _WIN32
                int e = WSAGetLastError();
                if (e == WSAETIMEDOUT || e == WSAEINTR) continue;
                if (stop_.load()) break;
                log_msg(CH_SPEC[ch_].name, std::string("recv err ") + std::to_string(e));
#else
                if (errno == EAGAIN || errno == EWOULDBLOCK || errno == EINTR) continue;
                if (stop_.load()) break;
                log_msg(CH_SPEC[ch_].name, std::string("recv err ") + strerror(errno));
#endif
                break;
            }
        }
        sock_t old = sock_.exchange(INVALID_SOCK);
        if (old != INVALID_SOCK) sock_close(old);
        if (stop_.load()) break;
        sleep_steps(g_cfg.reconnect_delay_ms);
    }
    log_msg(CH_SPEC[ch_].name, "thread stopped");
}

void Channel::sleep_steps(int ms) {
    for (int w = 0; w < ms && !stop_.load(); w += 100)
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
}

// ---------------------------------------------------------------- 代码表 (30920)
int64_t fetch_code_list(const Config& cfg, std::string* out_raw) {
    sock_t s = tcp_connect(cfg.ip, PORT_CODELIST, cfg.rcvbuf);
    if (s == INVALID_SOCK) return -1;
    std::string req = std::string("level2_api_33617get_allmarket2\nlogin_user\n") +
                      cfg.user + "\n" + cfg.pass + "\n\n";
    bool ok = send_all(s, req.data(), req.size());
    if (!ok) { sock_close(s); return -1; }
    std::string blob;
    char tmp[64 * 1024];
    int64_t deadline = now_ms() + 15000;
    while (now_ms() < deadline && blob.find("#end") == std::string::npos) {
        int r = (int)recv(s, tmp, sizeof tmp, 0);
        if (r > 0) blob.append(tmp, (size_t)r);
        else if (r == 0) break;
        else {
#ifdef _WIN32
            int e = WSAGetLastError();
            if (e != WSAETIMEDOUT && e != WSAEINTR) break;
#else
            if (errno != EAGAIN && errno != EWOULDBLOCK && errno != EINTR) break;
#endif
        }
    }
    sock_close(s);
    if (out_raw) *out_raw = blob;
    size_t b = blob.find('#');
    size_t e = blob.rfind("#end");
    if (b == std::string::npos || e == std::string::npos || e <= b) return -1;
    std::string mid = blob.substr(b + 1, e - b - 1);
    int64_t cnt = 0;
    size_t pos = 0;
    while (pos < mid.size()) {
        size_t nl = mid.find('\n', pos);
        if (nl == std::string::npos) nl = mid.size();
        std::string line = mid.substr(pos, nl - pos);
        pos = nl + 1;
        if (line.find('\t') != std::string::npos) ++cnt;
    }
    return cnt;
}

} // namespace mkt
