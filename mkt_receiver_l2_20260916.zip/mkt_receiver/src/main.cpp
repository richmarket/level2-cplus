// mkt_receiver - 高性能 Level2 行情 TCP 接收端主程序
// 用法:
//   mkt_recv [--ip <行情IP>] [--user <账号>] [--pass <密码>]
//           [--write-files] [--out out] [--verbose]
//           [--watchdog 30] [--reconnect-ms 5000] [--stats-sec 5]
//           [--chans market,tran,order,index,queue,option]
//           [--list]        # 拉一次全市场代码表数量后退出
//           [--selftest]    # 离线自测(不联网): 拆帧/解压/解析
#include "common.hpp"
#include "chan.hpp"
#include "sink.hpp"
#include "frame.hpp"
#include "inflate.hpp"
#include "records.hpp"
#include <csignal>
#include <thread>
#include <vector>
#include <string>
#include <cstring>
#include <chrono>
#include <memory>

using namespace mkt;

// 纯统计模式 sink (记录条数由 Channel::stats_ 计数, 这里直接丢弃)
struct NullSink : Sink {
    void on_records(Chan, const RecordView*, size_t) override {}
};

// ---------------------------------------------------------------- 参数解析
static bool parse_chans(const std::string& s, bool want[CH_NUM]) {
    for (int i = 0; i < CH_NUM; ++i) want[i] = false;
    size_t pos = 0;
    while (pos <= s.size()) {
        size_t c = s.find(',', pos);
        std::string tok = s.substr(pos, c == std::string::npos ? std::string::npos : c - pos);
        bool found = false;
        for (int i = 0; i < CH_NUM; ++i) {
            if (tok == CH_SPEC[i].name || tok == CH_SPEC[i].login) { want[i] = true; found = true; }
        }
        if (!found) return false;
        if (c == std::string::npos) break;
        pos = c + 1;
    }
    return true;
}

// ---------------------------------------------------------------- 自测(离线)
static int selftest() {
    int fail = 0;
#define CHECK(cond, msg) do { if (!(cond)) { fprintf(stderr, "FAIL: %s\n", msg); ++fail; } \
                             else fprintf(stdout, "ok  : %s\n", msg); } while (0)

    // 1) gzip 压缩/解压往返
    const char* txt = "600000.SH|600000|20260907|093000000|1|10.01|10.02|10.00|9.99|10.01|...|end";
    std::vector<uint8_t> gz, back;
    CHECK(gzip_compress((const uint8_t*)txt, strlen(txt), gz), "gzip_compress");
    CHECK(gunzip(gz.data(), gz.size(), back), "gunzip");
    CHECK(back.size() == strlen(txt) && memcmp(back.data(), txt, back.size()) == 0,
          "gzip roundtrip equal");

    // 2) 构造市场 payload: 2 条记录(每条 59+ 字段, 十档快照)
    const char* payload =
        "600000.SH|600000|20260907|093000000|1|1001|1002|1000|999|1001|"
        "1010|1009|1008|1007|1006|1005|1004|1003|1002|1001|"      // 卖价1-10
        "1|2|3|4|5|6|7|8|9|10|"                                   // 卖量1-10
        "990|991|992|993|994|995|996|997|998|999|"                // 买价1-10
        "10|9|8|7|6|5|4|3|2|1|"                                   // 买量1-10
        "5|12345|123456789|1000|2000|10001|10002|1003|1004"       // 笔数/总量/额/委买/委卖/均买/均卖/涨停/跌停
        "#"
        "000002.SZ|000002|20260907|093000100|1|2001|2002|2000|1999|2001|"
        "2010|2009|2008|2007|2006|2005|2004|2003|2002|2001|"
        "1|2|3|4|5|6|7|8|9|10|"
        "1990|1991|1992|1993|1994|1995|1996|1997|1998|1999|"
        "10|9|8|7|6|5|4|3|2|1|"
        "5|22345|223456789|2000|3000|20001|20002|2003|2004";
    std::vector<uint8_t> pgz;
    CHECK(gzip_compress((const uint8_t*)payload, strlen(payload), pgz), "payload gzip");

    // 3) 组 TCP 流: [gzip帧 @market@] + [明文帧 @Market@] + 中间夹心跳
    std::vector<uint8_t> s2;
    {
        std::string h1 = "SS_begin@market@";
        char len[14]; snprintf(len, sizeof len, "%013zu", pgz.size());
        h1 += len;
        s2.insert(s2.end(), h1.begin(), h1.end());
        s2.insert(s2.end(), pgz.begin(), pgz.end());
    }
    const char* payload2 =
        "510050.SH|510050|20260907|093000200|1|3001|3002|3000|2999|3001|"
        "1|2|3|4|5|6|7|8|9|10|1|2|3|4|5|6|7|8|9|10|"
        "2990|2991|2992|2993|2994|2995|2996|2997|2998|2999|"
        "10|9|8|7|6|5|4|3|2|1|5|32345|323456789|3000|4000|30001|30002|3003|3004";
    {
        std::string h2 = "SS_begin@Market@";
        char len[14]; snprintf(len, sizeof len, "%013zu", strlen(payload2));
        h2 += len;
        s2.insert(s2.end(), h2.begin(), h2.end());
        s2.insert(s2.end(), payload2, payload2 + strlen(payload2));
    }
    const char* hb = "Heart_beart";
    // 心跳只应出现在帧与帧之间(服务器按帧发送); 插到帧1结束边界处
    std::vector<uint8_t> s3;
    size_t f1_end = 29 + pgz.size();           // 帧1 = 头29 + gzip(payload)
    s3.insert(s3.end(), s2.begin(), s2.begin() + f1_end);
    s3.insert(s3.end(), hb, hb + 11);                    // 帧间心跳
    s3.insert(s3.end(), s2.begin() + f1_end, s2.end());

    // 4) 乱序小块喂入 -> 应恰好 2 帧
    std::vector<uint8_t> buf; size_t pos = 0; size_t got = 0;
    {
        std::vector<uint8_t> piece;
        const size_t ch = 37;
        for (size_t k = 0; k < s3.size(); k += ch) {
            piece.assign(s3.begin() + k, s3.begin() + std::min(k + ch, s3.size()));
            feed_stream(buf, pos, piece.data(), piece.size(),
                        [&](const Frame&) { ++got; });
        }
    }
    CHECK(got == 2, "2 frames assembled across fragmented tcp chunks");

    // 5) 整段喂入并解析
    std::vector<uint8_t> buf2; size_t pos2 = 0;
    struct Parsed { std::string type; bool gzip; std::vector<RecordView> recs; };
    std::vector<Parsed> parsed;
    feed_stream(buf2, pos2, s3.data(), s3.size(), [&](const Frame& f) {
        Parsed p; p.type = f.type; p.gzip = f.gzip;
        std::vector<uint8_t> out;
        if (f.gzip) gunzip(f.payload, f.len, out);
        const char* d = f.gzip ? (const char*)out.data() : (const char*)f.payload;
        size_t n = f.gzip ? out.size() : f.len;
        RecordView rv[64];
        size_t cnt = split_records(d, n, rv, 64);
        p.recs.assign(rv, rv + cnt);
        parsed.push_back(std::move(p));
    });
    CHECK(parsed.size() == 2, "2 frames parsed in one shot");
    if (parsed.size() == 2) {
        CHECK(parsed[0].gzip && parsed[0].type == "@market@", "frame1 gzip @market@");
        CHECK(!parsed[1].gzip && parsed[1].type == "@Market@", "frame2 plain @Market@");
        CHECK(parsed[0].recs.size() == 2, "frame1 has 2 records");
        if (parsed[0].recs.size() >= 1) {
            FieldView f[64];
            size_t nf = split_fields(parsed[0].recs[0], f, 64);
            CHECK(nf >= 59, "record0 has >=59 fields (十档)");
            if (nf >= 59) {
                CHECK(f[0].n == 9 && memcmp(f[0].p, "600000.SH", 9) == 0, "rec0 stdcode=600000.SH");
                CHECK(f[1].n == 6 && memcmp(f[1].p, "600000", 6) == 0, "rec0 code=600000");
                CHECK(f[3].n == 9 && memcmp(f[3].p, "093000000", 9) == 0, "rec0 time=093000000");
                CHECK(field_i64(f, nf, 52) == 123456789, "rec0 field52 成交额=123456789");
                CHECK(field_i64(f, nf, 57) == 1003, "rec0 field57 涨停价=1003");
                CHECK(field_i64(f, nf, 58) == 1004, "rec0 field58 跌停价=1004");
                CHECK(field_i64(f, nf, 53) == 1000 && field_i64(f, nf, 54) == 2000,
                      "rec0 委买/委卖总量");
            }
        }
    }

    // 6) split_records 空段语义 (RemoveEmptyEntries)
    RecordView rv2[16];
    CHECK(split_records("a#b##c#", 7, rv2, 16) == 3, "records skip empty segs (a,b,c)");
    // 7) 非法长度帧: 不崩溃不产生帧
    std::vector<uint8_t> jb; size_t jp = 0; size_t jf = 0;
    const char* bad = "SS_begin@market@9999999999999xxxx";
    feed_stream(jb, jp, (const uint8_t*)bad, strlen(bad), [&](const Frame&) { ++jf; });
    CHECK(jf == 0, "oversize length frame skipped");
    // 8) 纯心跳流: 无帧
    std::vector<uint8_t> hb2; size_t hp = 0; size_t hf = 0;
    const char* only_hb = "Heart_beartHeart_beart";
    feed_stream(hb2, hp, (const uint8_t*)only_hb, strlen(only_hb), [&](const Frame&) { ++hf; });
    CHECK(hf == 0, "heartbeat-only yields 0 frames");

    if (fail == 0) { fprintf(stdout, "SELFTEST PASS\n"); return 0; }
    fprintf(stderr, "SELFTEST FAIL (%d)\n", fail);
    return 1;
#undef CHECK
}

// ---------------------------------------------------------------- main
static void on_signal(int) { g_stop.store(true); }

int main(int argc, char** argv) {
    if (!sock_init()) { fprintf(stderr, "socket init failed\n"); return 1; }
    bool want[CH_NUM];
    for (int i = 0; i < CH_NUM; ++i) want[i] = true;

    auto need_val = [&](int& i, const char* flag) -> std::string {
        if (i + 1 >= argc) { fprintf(stderr, "%s needs value\n", flag); exit(2); }
        return argv[++i];
    };
    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "--ip") g_cfg.ip = need_val(i, "--ip");
        else if (a == "--user") g_cfg.user = need_val(i, "--user");
        else if (a == "--pass") g_cfg.pass = need_val(i, "--pass");
        else if (a == "--out") g_cfg.out_dir = need_val(i, "--out");
        else if (a == "--watchdog") g_cfg.watchdog_sec = atoi(need_val(i, "--watchdog").c_str());
        else if (a == "--reconnect-ms") g_cfg.reconnect_delay_ms = atoi(need_val(i, "--reconnect-ms").c_str());
        else if (a == "--stats-sec") g_cfg.stats_sec = atoi(need_val(i, "--stats-sec").c_str());
        else if (a == "--write-files") g_cfg.write_files = true;
        else if (a == "--verbose") g_cfg.verbose = true;
        else if (a == "--chans") { if (!parse_chans(need_val(i, "--chans"), want)) { fprintf(stderr, "bad --chans\n"); return 2; } }
        else if (a == "--selftest") return selftest();
        else if (a == "--list") {
            int64_t cnt = fetch_code_list(g_cfg, nullptr);
            if (cnt < 0) { fprintf(stderr, "code list fetch failed\n"); return 1; }
            printf("code list entries: %lld\n", (long long)cnt);
            return 0;
        }
        else { fprintf(stderr, "unknown arg: %s\n", a.c_str()); return 2; }
    }
    if (const char* e = getenv("L2_IP")) g_cfg.ip = e;
    if (const char* e = getenv("L2_USER")) g_cfg.user = e;
    if (const char* e = getenv("L2_PASS")) g_cfg.pass = e;
    if (g_cfg.user.empty() || g_cfg.pass.empty()) {
        fprintf(stderr, "need account: set env L2_USER/L2_PASS or pass --user/--pass\n");
        return 2;
    }

    signal(SIGINT, on_signal);
    signal(SIGTERM, on_signal);

    int active = 0;
    for (int i = 0; i < CH_NUM; ++i) if (want[i]) ++active;
    if (active == 0) { fprintf(stderr, "no channels selected\n"); return 2; }

    fprintf(stdout, "mkt_receiver ip=%s user=%s channels:", g_cfg.ip.c_str(), g_cfg.user.c_str());
    for (int i = 0; i < CH_NUM; ++i) if (want[i]) fprintf(stdout, " %s", CH_SPEC[i].name);
    fprintf(stdout, "\nwrite_files=%s out=%s\n", g_cfg.write_files ? "on" : "off",
            g_cfg.out_dir.c_str());
    fflush(stdout);

    // sink
    std::unique_ptr<Sink> sink;
    if (g_cfg.write_files) sink = std::make_unique<FileSink>(g_cfg.out_dir);
    else                  sink = std::make_unique<NullSink>();

    std::vector<std::unique_ptr<Channel>> chans;
    for (int i = 0; i < CH_NUM; ++i) {
        if (!want[i]) continue;
        chans.emplace_back(std::make_unique<Channel>((Chan)i, *sink));
        chans.back()->start();
    }

    // 统计线程
    int64_t t0 = now_ms();
    std::thread stats_th([&] {
        struct Snap { uint64_t recs; };
        Snap prev[CH_NUM]{};
#ifndef _WIN32
        // 进程 CPU%: /proc/self/stat utime(14)+stime(15), tick=10ms
        auto read_cpu = []() -> uint64_t {
            FILE* fp = fopen("/proc/self/stat", "r");
            if (!fp) return 0;
            char line[512];
            uint64_t ticks = 0;
            if (fgets(line, sizeof line, fp)) {
                char* tail = strrchr(line, ')');
                if (tail) {
                    char* save = nullptr;
                    char* tok = strtok_r(tail + 2, " ", &save);
                    int idx = 0;
                    uint64_t cpuu = 0, cpus = 0;
                    while (tok && idx <= 13) {
                        if (idx == 11) cpuu = strtoull(tok, nullptr, 10);
                        if (idx == 12) cpus = strtoull(tok, nullptr, 10);
                        tok = strtok_r(nullptr, " ", &save);
                        ++idx;
                    }
                    ticks = cpuu + cpus;
                }
            }
            fclose(fp);
            return ticks;
        };
        uint64_t prev_cpu = read_cpu();
#endif
        while (!g_stop.load()) {
            std::this_thread::sleep_for(std::chrono::seconds(g_cfg.stats_sec));
            int64_t now = now_ms();
            double dt = (now - t0) / 1000.0; t0 = now;
#ifdef _WIN32
            double cpu_pct = -1;
#else
            uint64_t cpu_ticks = read_cpu();
            double cpu_pct = (double)(cpu_ticks - prev_cpu) * 10.0 / 1000.0 / dt * 100.0;
            prev_cpu = cpu_ticks;
#endif
            for (auto& c : chans) {
                int ci = (int)c->kind();
                auto& stt = *c->stats();
                uint64_t r = (uint64_t)stt.recs.load();
                double rps = dt > 0 ? (r - prev[ci].recs) / dt : 0;
                prev[ci].recs = r;
                int64_t blk = c->backlog_bytes();
                int64_t age = stt.age_latest.load();
                int64_t agemx = stt.age_max.load();
                fprintf(stdout, "%s %-8s %12.0f rec/s tot=%-12llu blk=%-6s age=%-5s mx=%-5s gzMB=%-6.1f fails=%-4llu recon=%llu\n",
                        local_hhmmssfff().c_str(), CH_SPEC[ci].name, rps,
                        (unsigned long long)r,
                        blk < 0 ? "-" : std::to_string(blk / 1024).c_str(),
                        age < 0 ? "-" : std::to_string(age).c_str(),
                        agemx < 0 ? "-" : std::to_string(agemx).c_str(),
                        (double)stt.bytes_gz.load() / 1e6,
                        (unsigned long long)stt.inflate_fail.load(),
                        (unsigned long long)stt.reconnect.load());
            }
            if (cpu_pct >= 0)
                fprintf(stdout, "%s CPU %5.1f%%\n", local_hhmmssfff().c_str(), cpu_pct);
            fflush(stdout);
        }
    });

    while (!g_stop.load())
        std::this_thread::sleep_for(std::chrono::milliseconds(200));

    for (auto& c : chans) c->stop();
    stats_th.join();
    chans.clear();            // join 各通道线程
    fprintf(stdout, "bye\n");
    return 0;
}
