// mkt_receiver - 高性能 Level2 行情 TCP 接收端 (C++ 版)
// 协议依据: C# 原版 login.cs / SS_data.cs / Program.cs (ss_level2)
// 与 C# 版一一对应: 6 路行情通道 + 1 路代码表通道
#pragma once

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <atomic>
#include <chrono>
#include <ctime>

namespace mkt {

// ---------------------------------------------------------------- 通道定义
enum Chan : int {
    CH_INDEX  = 0,
    CH_OPTION = 1,
    CH_MARKET = 2,
    CH_QUEUE  = 3,
    CH_TRAN   = 4,
    CH_ORDER  = 5,
    CH_NUM    = 6
};

// 与 C# login.cs 各 Login_xxx0() 完全一致
struct ChanSpec {
    const char* name = nullptr;        // 显示名
    const char* login = nullptr;       // 登录协议中的通道名
    const char* frame_type = nullptr;  // 帧类型标志特征(小写=压缩) 仅用于日志
    int         port = 0;              // 端口
};
extern const ChanSpec CH_SPEC[CH_NUM];

constexpr int PORT_CODELIST = 30920;   // 全市场代码表 (Program.cs getallmarket)

// ---------------------------------------------------------------- 配置
struct Config {
    std::string ip    = "";
    // 账号密码不内置: 用环境变量 L2_USER / L2_PASS 传入 (或命令行 --user/--pass)
    std::string user  = "";
    std::string pass  = "";
    std::string out_dir = "out";
    bool write_files  = false;   // 是否镜像原版落盘 CSV(按 code_{date}.csv)
    bool verbose      = false;
    int  watchdog_sec = 30;      // 心跳看门狗, 与 C# 30s 一致
    int  reconnect_delay_ms = 5000;
    int  rcvbuf       = 8 << 20; // SO_RCVBUF 8MB
    int  stats_sec    = 5;
};
extern Config g_cfg;
extern std::atomic<bool> g_stop;

// ---------------------------------------------------------------- 工具
inline int64_t now_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count();
}

// 时间显示统一北京时区 (见 beijing_hhmmssfff)
// (旧版容器时区版已删除)

// HHmmssfff(如 93000000) -> 当日毫秒数; 非法返回-1
inline int64_t hhmmssfff_to_ms(int64_t v) {
    if (v < 0) return -1;
    int64_t hh = v / 10000000;
    int64_t mm = (v / 100000) % 100;
    int64_t ss = (v / 1000) % 100;
    int64_t ff = v % 1000;
    if (hh > 23 || mm > 59 || ss > 60) return -1;
    return hh * 3600000 + mm * 60000 + ss * 1000 + ff;
}

// 当前 UTC epoch 毫秒 (不依赖本地时区)
inline int64_t now_epoch_ms() {
    using namespace std::chrono;
    return duration_cast<milliseconds>(system_clock::now().time_since_epoch()).count();
}

// 公历 -> 自 epoch 的天数 (Howard Hinnant civil_from_days 逆运算)
inline int64_t days_from_civil(int y, unsigned m, unsigned d) {
    y -= m <= 2;
    const int64_t era = (y >= 0 ? y : y - 399) / 400;
    const unsigned yoe = (unsigned)(y - era * 400);
    const unsigned doy = (153 * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
    const unsigned doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
    return era * 146097 + (int64_t)doe - 719468;
}

// 行情记录(北京日期 YYYYMMDD + 时间 HHmmssfff) -> UTC epoch 毫秒; 非法返回 -1
inline int64_t rec_epoch_ms(int64_t date_ymd, int64_t t_hhmmssfff) {
    int64_t msod = hhmmssfff_to_ms(t_hhmmssfff);
    if (msod < 0 || date_ymd < 10000101 || date_ymd > 99991231) return -1;
    int y = (int)(date_ymd / 10000);
    int m = (int)(date_ymd / 100 % 100);
    int d = (int)(date_ymd % 100);
    if (m < 1 || m > 12 || d < 1 || d > 31) return -1;
    // 北京 = UTC+8 (A股无夏令时)
    return days_from_civil(y, (unsigned)m, (unsigned)d) * 86400000 + msod - 8 * 3600000;
}

// 北京时区 HHmmssfff (供日志/统计; A股语境固定 UTC+8)
inline std::string beijing_hhmmssfff() {
    int64_t ms = now_epoch_ms() + 8 * 3600000;   // UTC -> 北京
    int64_t msod = ms % 86400000;
    if (msod < 0) msod += 86400000;
    char b[16];
    snprintf(b, sizeof b, "%02lld%02lld%02lld%03lld",
             (long long)(msod / 3600000), (long long)(msod / 60000 % 60),
             (long long)(msod / 1000 % 60), (long long)(msod % 1000));
    return b;
}

// 兼容旧名: 日志时间统一北京
inline std::string local_hhmmssfff() { return beijing_hhmmssfff(); }

inline void log_msg(const char* tag, const std::string& s) {
    // 北京时区时间戳 (非热路径)
    int64_t ms = now_epoch_ms() + 8 * 3600000;
    time_t t = (time_t)(ms / 1000);
    std::tm tm{};
#ifdef _WIN32
    gmtime_s(&tm, &t);
#else
    gmtime_r(&t, &tm);
#endif
    char b[64];
    snprintf(b, sizeof b, "[%02d:%02d:%02d] ", tm.tm_hour, tm.tm_min, tm.tm_sec);
    fprintf(stderr, "%s[%s] %s\n", b, tag, s.c_str());
    fflush(stderr);
}

// 快速 ASCII->整数 (字段可能带前导0)
inline int64_t parse_i64(const char* p, size_t n) {
    if (!n) return 0;
    bool neg = (p[0] == '-');
    if (neg) { ++p; --n; }
    int64_t v = 0;
    for (size_t i = 0; i < n; ++i) {
        unsigned char c = (unsigned char)p[i];
        if (c < '0' || c > '9') break;
        v = v * 10 + (c - '0');
    }
    return neg ? -v : v;
}

inline double pow10(int e) { double r = 1; while (e-- > 0) r *= 10; return r; }

// 快速 ASCII->double
inline double parse_f64(const char* p, size_t n) {
    // 不带指数的手写解析(行情字段无科学计数法)
    int64_t ip = 0, fp = 0; int flen = 0; bool neg = false; bool dot = false;
    for (size_t i = 0; i < n; ++i) {
        unsigned char c = (unsigned char)p[i];
        if (c == '-') { neg = true; }
        else if (c == '.') { dot = true; }
        else if (c >= '0' && c <= '9') {
            if (!dot) ip = ip * 10 + (c - '0');
            else { if (flen < 18) { fp = fp * 10 + (c - '0'); ++flen; } }
        } else break;
    }
    double d = (double)ip + (double)fp / pow10(flen);
    return neg ? -d : d;
}

// ---------------------------------------------------------------- 跨平台 socket
#ifdef _WIN32
  #ifndef WIN32_LEAN_AND_MEAN
    #define WIN32_LEAN_AND_MEAN
  #endif
  #include <winsock2.h>
  #include <ws2tcpip.h>
  using sock_t = SOCKET;
  constexpr sock_t INVALID_SOCK = INVALID_SOCKET;
  inline void sock_close(sock_t s) { closesocket(s); }
  inline int  sock_err() { return WSAGetLastError(); }
  inline bool sock_init() { WSADATA w; return WSAStartup(MAKEWORD(2,2), &w) == 0; }
  inline void sock_shutdown(sock_t s) { shutdown(s, SD_BOTH); }
#else
  #include <sys/socket.h>
  #include <netinet/in.h>
  #include <netinet/tcp.h>
  #include <arpa/inet.h>
  #include <unistd.h>
  #include <fcntl.h>
  using sock_t = int;
  constexpr sock_t INVALID_SOCK = -1;
  inline void sock_close(sock_t s) { close(s); }
  inline int  sock_err() { return errno; }
  inline bool sock_init() { return true; }
  inline void sock_shutdown(sock_t s) { shutdown(s, SHUT_RDWR); }
#endif

} // namespace mkt
