// 数据出口(sink): 接收按通道拆好的一条条记录
// v1 提供两个实现: 统计 + 文件落盘(镜像原版 per-code CSV)
#pragma once

#include <cstdint>
#include <string>
#include <unordered_map>
#include "records.hpp"
#include "common.hpp"

namespace mkt {

// 每帧回调(已解压/明文) -> 记录数组 (begin 指向帧内缓冲, 仅回调期间有效)
// 返回: 本帧消费到的记录数(现恒等于传入 count)
struct Sink {
    virtual ~Sink() = default;
    virtual void on_records(Chan ch, const RecordView* recs, size_t count) = 0;
    virtual void on_raw(Chan ch, const char* data, size_t n) { (void)ch; (void)data; (void)n; }
};

// ---- 统计(计数/字节/速率, 供 main 定时打印) ----
struct ChanStats {
    std::atomic<uint64_t> recs{0};      // 记录条数
    std::atomic<uint64_t> bytes_in{0};  // TCP 原始字节
    std::atomic<uint64_t> bytes_gz{0};  // gzip payload 字节
    std::atomic<uint64_t> bytes_txt{0}; // 解压后文本字节
    std::atomic<uint64_t> frames{0};
    std::atomic<uint64_t> inflate_fail{0};
    std::atomic<uint64_t> reconnect{0};
    std::atomic<int64_t>  age_latest{-1};   // 最近帧数据龄期ms(本地解析时刻-行情时刻)
    std::atomic<int64_t>  age_max{-1};      // 会话最大数据龄期ms
};

class StatsSink : public Sink {
public:
    ChanStats st[CH_NUM];
    void on_records(Chan ch, const RecordView* recs, size_t count) override {
        st[ch].recs.fetch_add(count, std::memory_order_relaxed);
    }
    void on_raw(Chan ch, const char* data, size_t n) override {
        st[ch].bytes_in.fetch_add(n, std::memory_order_relaxed);
    }
};

// ---- 文件落盘: out/{date}/{channel}/{code}_{date}.csv (镜像原版) ----
// 原版: code_sw[code].WriteLine(记录.replace('|',',') + "," + 本地接收时间)
class FileSink : public Sink {
public:
    FileSink(std::string out_dir) : dir_(std::move(out_dir)) {}
    ~FileSink() override;
    void on_records(Chan ch, const RecordView* recs, size_t count) override;
private:
    struct OutFile {
        FILE* f = nullptr;
        std::string path;
        size_t since_flush = 0;
    };
    void write_line(Chan ch, const RecordView& r);
    std::string dir_;
    // key = ch|codelist
    // 简化: 每通道一个按 code 的 map
    struct ChannelFiles { std::unordered_map<std::string, OutFile> by_code; };
    ChannelFiles files_[CH_NUM];
};

} // namespace mkt
